package com.example.shayanmoradi.criminalintentbeta;

import android.support.v4.app.Fragment;

public class Crime_list extends SingleFragmentActivity {

    @Override
    public Fragment createFragment() {
        return new CrimeFragment();
    }
}

package com.example.shayanmoradi.criminalintentbeta;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import com.example.shayanmoradi.criminalintentbeta.Model.Crime;
import com.example.shayanmoradi.criminalintentbeta.Model.CrimeLab;


/**
 * A simple {@link Fragment} subclass.
 */
public class CrimeFragment extends Fragment {
    private Crime mcrime;
    private EditText mTitleFireld;
    private Button mAddBtn;
    private CheckBox mSlovedCheckBox;
    private Button goToList;
    private CheckBox needPoliceOrNOt;

    public boolean callPolice = false;
    public boolean sloved = false;



    public CrimeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mcrime = new Crime();
        Log.d("test", "onCreate");

    }

    @Override

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_crime, container, false);
        mAddBtn = view.findViewById(R.id.button);
        needPoliceOrNOt = view.findViewById(R.id.checkPolice);
        mSlovedCheckBox = view.findViewById(R.id.Crime_sovled);
        mTitleFireld = view.findViewById(R.id.editText);
        goToList = view.findViewById(R.id.go_to_list);
        mTitleFireld.setText(mcrime.getmTitle());
        mAddBtn.setText(mcrime.getmDate().toString());
        mSlovedCheckBox.setChecked(mcrime.ismSloved());

        Log.d("test", "onCreateView");
        goToList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), CrimeLIstActivity.class);
                startActivity(intent);
            }
        });
        mAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CrimeLab.addCrime(mTitleFireld.getText().toString(), callPolice,sloved);
            }
        });
        mTitleFireld.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                mcrime.setmTitle(charSequence.toString());


            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        mSlovedCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (mSlovedCheckBox.isChecked()==true) {
                    sloved = true;
                }else if(mSlovedCheckBox.isChecked()==false){
                    sloved=false;
                }
            }
        });
        needPoliceOrNOt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (needPoliceOrNOt.isChecked()==true) {
                    callPolice = true;
                }else if(needPoliceOrNOt.isChecked()==false){
                    callPolice=false;
                }
            }
        });

        return view;

    }

}


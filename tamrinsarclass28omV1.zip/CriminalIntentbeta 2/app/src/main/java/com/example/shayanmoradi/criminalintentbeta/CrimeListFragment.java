package com.example.shayanmoradi.criminalintentbeta;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.shayanmoradi.criminalintentbeta.Model.Crime;
import com.example.shayanmoradi.criminalintentbeta.Model.CrimeLab;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class CrimeListFragment extends Fragment {
    RecyclerView mrecyclerView;
    public static boolean clickShouldWorkOrNot = false;

    public CrimeListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.activity_crime_list, container, false);
        mrecyclerView = view.findViewById(R.id.recyclerId);
//         mrecyclerView.setLayoutManager(new GridLayoutManager(getActivity(),3));
       // mrecyclerView.setLayoutManager(new GridLayoutManager(getActivity(),3));
//        LinearLayoutManager layoutManager
//                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
//
mrecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        CrimeLab crimeLab = CrimeLab.getInstance();
        List<Crime> crimeList = crimeLab.getCrimes();
        CrimeAdapter crimeAdapter = new CrimeAdapter(crimeList);
        mrecyclerView.setAdapter(crimeAdapter);

        return view;
    }
    private class CrimeHolderPolice extends RecyclerView.ViewHolder {
        public TextView mTitleTxt;
        public TextView mDateTxt;
        public TextView mTitleTxt2;
        public TextView mDateTxt2;
        public ImageView police_image ;

        public Button mCallPloice;

        public CrimeHolderPolice(View itemView) {
            super(itemView);
            police_image=itemView.findViewById(R.id.crime_solved);
            mTitleTxt = itemView.findViewById(R.id.textView4);
            mDateTxt = itemView.findViewById(R.id.textView3);
            mTitleTxt2 = itemView.findViewById(R.id.textView4);
            mDateTxt2 = itemView.findViewById(R.id.textView32);

            mCallPloice = itemView.findViewById(R.id.callPliceBtn);
            if (clickShouldWorkOrNot == true) {

            }}

        }
    private class CrimeHolder extends RecyclerView.ViewHolder {
        public TextView mTitleTxt;
        public TextView mDateTxt;
        public TextView mTitleTxt2;
        public TextView mDateTxt2;
public ImageView police_image2 ;

        public Button mCallPloice;

        public CrimeHolder(View itemView) {
            super(itemView);
            police_image2=itemView.findViewById(R.id.crime_solved2);
            mTitleTxt = itemView.findViewById(R.id.textView4);
            mDateTxt = itemView.findViewById(R.id.textView3);
            mTitleTxt2 = itemView.findViewById(R.id.textView4);
            mDateTxt2 = itemView.findViewById(R.id.textView32);

            mCallPloice = itemView.findViewById(R.id.callPliceBtn);
            if (clickShouldWorkOrNot == true) {
                mCallPloice.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(getActivity(), "calling police...", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }

    }




    public class CrimeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private List<Crime> mcrimeList;

        public CrimeAdapter(List<Crime> crimeList) {
            mcrimeList = crimeList;
        }

        @Override
        public int getItemViewType(int position) {
            // Just as an example, return 0 or 2 depending on position
            // Note that unlike in ListView adapters, types don't have to be contiguous
            if (mcrimeList.get(position).isNeedToCallPolice() == true) {
                clickShouldWorkOrNot = true;
                return 0;

            } else {
                clickShouldWorkOrNot = false;
                return 2;
            }
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            switch (viewType) {
                case 0:
                    LayoutInflater inflater = LayoutInflater.from(getActivity());
                    View view = inflater.inflate(R.layout.fragment_crime_item, parent, false);
                    CrimeHolder crimeHolder = new CrimeHolder(view);
                    return crimeHolder;
                case 2:
                    LayoutInflater inflater2 = LayoutInflater.from(getActivity());
                    View view2 = inflater2.inflate(R.layout.fragment_crime_item_with_out_btn, parent, false);
                    CrimeHolderPolice crimeHolder2 = new CrimeHolderPolice(view2);
                    return crimeHolder2;

            }
            LayoutInflater inflater = LayoutInflater.from(getActivity());
            View view = inflater.inflate(R.layout.fragment_crime_item, parent, false);
            CrimeHolder crimeHolder = new CrimeHolder(view);
            return crimeHolder;

        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            Crime crime = mcrimeList.get(position);
            switch (holder.getItemViewType()) {
                case 0:

                    (( CrimeHolder)holder).mTitleTxt.setText(crime.getmTitle());
                    (( CrimeHolder)holder).mDateTxt.setText(crime.getmDate().toString());
                    break;

                case 2:

//
//                        holder.mCallPloice.setVisibility(View.INVISIBLE);


                    (( CrimeHolderPolice)holder).mTitleTxt2.setText(crime.getmTitle());
                    (( CrimeHolderPolice)holder).mDateTxt2.setText(crime.getmDate().toString());
                    break;
            }


        }

        @Override
        public int getItemCount() {
            return mcrimeList.size();
        }
    }

}

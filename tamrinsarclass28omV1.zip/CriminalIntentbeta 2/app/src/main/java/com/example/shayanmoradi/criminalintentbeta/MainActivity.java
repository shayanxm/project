package com.example.shayanmoradi.criminalintentbeta;

import android.support.v4.app.Fragment;

public class MainActivity extends SingleFragmentActivity {
    @Override
    public Fragment createFragment() {

        CrimeFragment crimeFragment = new CrimeFragment();
        return crimeFragment;
    }
}
package com.example.shayanmoradi.criminalintentbeta;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;


public abstract class SingleFragmentActivity extends AppCompatActivity {
public abstract Fragment createFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    android.support.v4.app.FragmentManager fragmrntManger = getSupportFragmentManager();
//    FragmentManager crimeListFragmen = new ;

        if (fragmrntManger.findFragmentById(R.id.fragment_container)==null)
            fragmrntManger.beginTransaction()
            .add(R.id.fragment_container,createFragment())


                    .commit();
}}

package com.example.shayanmoradi.criminalintentbeta;

        import android.support.v4.app.Fragment;

public class CrimeLIstActivity  extends SingleFragmentActivity{


    @Override
    public Fragment createFragment() {
       CrimeListFragment crimeListFragment = new CrimeListFragment();
       return crimeListFragment;
    }
}

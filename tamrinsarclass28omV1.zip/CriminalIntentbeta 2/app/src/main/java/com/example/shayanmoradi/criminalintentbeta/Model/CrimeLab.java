package com.example.shayanmoradi.criminalintentbeta.Model;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


public class CrimeLab {
    private static CrimeLab instance;

    private static List<Crime> mCrimes;


    private CrimeLab() {
        mCrimes = new ArrayList<>();

    }
    public static void addCrime(String title,boolean callPollice,boolean sovled){
            Crime crime = new Crime();
            crime.setmTitle(title);
            crime.setmSloved(sovled);
            crime.setNeedToCallPolice(callPollice);

            mCrimes.add(crime);


    }

    public static CrimeLab getInstance() {
        if (instance == null)
            instance = new CrimeLab();

        return instance;
    }

    public List<Crime> getCrimes() {
        return mCrimes;
    }

    public Crime getCrime(UUID id) {
        for (Crime crime : mCrimes) {
            if (crime.getmId().equals(id))
                return crime;
        }

        return null;
    }
}
